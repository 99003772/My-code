#include "unity.h"
#include "main.h"


void setUp(){}

void tearDown(){}

void test_add1(void)
{
    TEST_ASSERT_EQUAL(20,add(5,15));
}

void test_add2(void)
{
    TEST_ASSERT_EQUAL(35,add(50,-15));
   
}
void test_add3(void)
{
    TEST_ASSERT_EQUAL(20,add(560,15));
   
}
void test_add4(void)
{
    TEST_ASSERT_EQUAL(100,add(-10,110));
   
}
void test_add5(void)
{
    TEST_ASSERT_EQUAL(-4,add(-2,-2));
   
}
void test_sub(void)
{
    TEST_ASSERT_EQUAL(10,sub(15,5));

}

void test_sub2(void)
{
    TEST_ASSERT_EQUAL(20,sub(15,5));

}

void test_sub3(void)
{
    TEST_ASSERT_EQUAL(10,sub(15,5));

}
void test_sub4(void)
{
    TEST_ASSERT_EQUAL(10,sub(15,5));

}
void test_sub5(void)
{
    TEST_ASSERT_EQUAL(10,sub(15,5));

}
void test_sub6(void)
{
    TEST_ASSERT_EQUAL(10,sub(15,5));

}

int main(void)
{ 
  UNITY_BEGIN();
  RUN_TEST(test_add1);
  RUN_TEST(test_add2);
  RUN_TEST(test_add3);
  RUN_TEST(test_add4);
  RUN_TEST(test_add5);
    RUN_TEST(test_sub);
    RUN_TEST(test_sub2);
    RUN_TEST(test_sub3);
    RUN_TEST(test_sub4);
    RUN_TEST(test_sub5);
    RUN_TEST(test_sub6);

  return UNITY_END();
}
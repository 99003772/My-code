#include<stdio.h>

int add(int num1,int num2);
int sub(int num1, int num2);
int multiply(int num1, int num2);
int div(int num1,int num2);

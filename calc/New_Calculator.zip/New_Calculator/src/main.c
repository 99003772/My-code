#include "main.h"


//Arithmatic
int add(int num1,int num2);
int sub(int num1, int num2);
int multiply(int num1, int num2);
int div(int num1,int num2);

//Trignomatry

int sine(int num);
int cosine(int num);
int tan1(int num);
int cot1(int num);
int cosec1(int num);

int add(int num1,int num2)
{
    int sum;
    sum=num1+num2;
    return sum;
}

int sub(int num1, int num2)
{
    int subt;
    subt=num1-num2;
    return subt;
}
int multiply(int num1, int num2)
{
    int mul;
    mul=num1*num2;
    return mul;
}
int div(int num1,int num2)
{
    int division;
    division=num1/num2;
    return division;
}

// Trignoamtry Equation function


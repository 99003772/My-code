#ifndef Calc_pnc_H
#define Calc_pnc_H

#include<stdio.h>
long permutation(int, int);
long combination(int, int);
long factorial(int);

#endif

#include<stdio.h>
long permutation(int, int);
long combination(int, int);
long factorial(int);

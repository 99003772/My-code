#ifndef Calc_geo_H
#define Calc_geo_H

#include<stdio.h>
void Rectangle();
void Square();
void Circle();

#endif

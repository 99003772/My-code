#include<stdio.h>
void Rectangle();
void Square();
void Circle();

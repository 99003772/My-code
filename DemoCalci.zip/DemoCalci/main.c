#include <stdio.h>
#include <stdlib.h>
#include"Calc_pnc.h"
#include"Calc_geo.h"
int main()
{
    int ch;
    printf("Choose the Functionality we want\n1: Arithmetic\n2: Exponential\n3: Logarithm\n4: Permutation and Combination\n5: Geometry\n6: Square Root\n7: Volume\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1: int n, r,choice;
                printf("Enter n: ");
                scanf("%d", &n);
                printf("Enter r: ");
                scanf("%d", &r);
                printf("Choose operation :\n1: Permutation\n2: Combination\n");
                scanf("%d",&choice);
                if(choice==1)
                {
                    printf("Permutation = %ld\n", permutation(n,r));
                }
                else if(choice==2)
                {
                    printf("Combination = %ld\n", combination(n,r));
                }
                else
                {
                    printf("Wrong Operation chosen");
                    exit(0);
                }
        case 2:
    }


    return 0;
}
